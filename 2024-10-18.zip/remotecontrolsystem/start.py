from projectdesposetool import SERVERMANAGE


SERVERMANAGE.start()