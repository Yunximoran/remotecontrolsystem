import multiprocessing
# 什么是多进程队列通信


MESSAGEQUEUE = multiprocessing()

class Communication:
    def __init__(self):
        self.queue = multiprocessing.Queue()
        
    
    
    def __send(self, *args):
        pass
    
    def __writeInstruction(self):
        shell = " ".join(shell)
        return shell