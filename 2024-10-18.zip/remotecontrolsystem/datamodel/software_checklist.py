# 软件清单数据模型

from pydantic import BaseModel


class SoftWareCheckList(BaseModel):
    None
    