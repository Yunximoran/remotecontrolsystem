
"""
    项目初始化
导入包， 导入项目配置
"""
from .resolver import Resolver