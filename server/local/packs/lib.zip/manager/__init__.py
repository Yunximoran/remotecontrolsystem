from ._logger import Logger
from ..init.resolver import __resolver

class Manager:
    def __init__(self):
        pass
