from .tcp._tcp import _ProtoType as TCP
from .udp._udp import _ProtoType as UDP