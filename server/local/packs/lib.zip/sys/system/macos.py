from ._base import __BaseSystem


class MacOS(__BaseSystem):
    pass